﻿/*
 * Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.html or http://ckeditor.com/license
*/
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Web.UI;

[assembly: TagPrefix("CKEditor.NET", "CKEditor")]

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("CKEditor for ASP.NET")]
[assembly: AssemblyDescription("CKEditor ASP.NET Integration")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("CKSource - Frederico Knabben")]
[assembly: AssemblyProduct("CKEditor for ASP.NET")]
[assembly: AssemblyCopyright( "2003-2014, CKSource - Frederico Knabben" )]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]
[assembly: System.CLSCompliant(true)]
[assembly: System.Security.AllowPartiallyTrustedCallers]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("458f3655-ff90-4105-9a52-2f1d30e01f69")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion( "3.6.6.2" )]
[assembly: AssemblyFileVersion( "3.6.6.2" )]
